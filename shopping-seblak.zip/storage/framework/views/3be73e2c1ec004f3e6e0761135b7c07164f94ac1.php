<div class="row">
    <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-2 col-md-3 col-sm-4 col-xs-2 mb-3">
            <div class="card">
                <img src="<?php echo e(url('storage/' . $p->image)); ?>" height="100" class="card-img-top">
                <div class="card-body p-2">
                    <p class="card-title product-title mb-0 text-uppercase"><strong><?php echo e($p->name); ?></strong></p>
                    <p class="card-text mb-1">Rp. <?php echo e(number_format($p->price, 0, '', '.')); ?></p>
                    <button class="btn btn-danger" style="width: 100%"
                        onclick="addItemToCart(<?php echo e($p->id); ?>, '<?php echo e($p->name); ?>', '<?php echo e($p->price); ?>', '<?php echo e(url('storage/' . $p->image)); ?>')"><i
                            class="fas fa-cart-plus"></i></button>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH C:\Users\ACER\OneDrive\Plazafood\shopping-seblak\resources\views/landing/food.blade.php ENDPATH**/ ?>
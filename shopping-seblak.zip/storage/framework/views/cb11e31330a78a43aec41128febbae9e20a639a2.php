<?php $__env->startSection('food-content'); ?>
<div class="row">
    <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-lg-3 col-md-4 col-sm-6">
        <div class="card">
            <img src="<?php echo e(url('storage/'.$p->image)); ?>" height="100" class="card-img-top" alt="<?php echo e($p->name); ?>">
            <div class="card-body" style="padding: 1rem .5rem">
                <div class="d-flex align-items-center">
                    <div class="col-lg-8">
                        <p class="card-title"><?php echo e($p->name); ?></p>
                        <p class="card-text"><?php echo e($p->price); ?></p>
                    </div>
                    <div class="col-lg-4 d-flex flex-column">
                        <a href="#" class="btn btn-warning btn-sm mb-2" onclick="editProduct(<?php echo e($p->id); ?>)" data-toggle="modal" data-target="#kategoriEditModal"><i class="fas fa-edit"></i></a>
                        <button class="btn btn-danger btn-delete btn-sm" data-id="<?php echo e($p->id); ?>"><i class="fas fa-trash"></i></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('food.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ACER\Documents\Plazafood\shopping-seblak\resources\views/food/detail.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', $app_title); ?>

<?php $__env->startSection('content'); ?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><?php echo $__env->yieldContent('title'); ?></h1>
    <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm" data-toggle="modal" data-target="#kategoriModal">
        <i class="fas fa-plus fa-sm text-white-50"></i> Tambah Kategori
    </a>
</div>

<?php if($errors->any()): ?>
<div class="alert alert-danger">
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>

<div class="row mt-4">
    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-lg-2">
        <div class="card">
            <img src="<?php echo e(url('storage/'.$c->image)); ?>" height="100" class="card-img-top" alt="<?php echo e($c->name); ?>">
            <div class="card-body">
                <p class="card-title"><?php echo e($c->name); ?></p>
                <a href="#" class="btn btn-warning" onclick="editCategory(<?php echo e($c->id); ?>)" data-toggle="modal" data-target="#kategoriEditModal"><i class="fas fa-edit"></i></a>
                <button class="btn btn-danger btn-delete" data-id="<?php echo e($c->id); ?>"><i class="fas fa-trash"></i></button>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal-content'); ?>
<div class="modal fade" id="kategoriModal" tabindex="-1" aria-labelledby="kategoriModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="kategoriModalLabel">Tambah Kategori</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="<?php echo e(url('category')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="name">Nama Kategori</label>
                        <input type="text" name="name" id="name" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="image">Gambar</label>
                        <input type="file" name="image" id="image" class="form-control">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Kembali</button>
                    <button type="submit" class="btn btn-primary">Tambah</button>
                </div>
            </form>
        </div>
    </div>
</div>
<div class="modal fade" id="kategoriEditModal" tabindex="-1" aria-labelledby="kategoriEditModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="kategoriEditModalLabel">Edit Kategori</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div id="form-edit"></div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script-content'); ?>
<script>
    function editCategory(params) {
        $.ajax({
            url: '<?php echo e(url("category")); ?>/'+params,
            type: 'get',
            success: function (response) {
                $("#form-edit").html(response);
            }
        })
    }

    $(document).ready(function () {
        $(".btn-delete").click(function () {
            let data = $(this).data('id');
            console.log(data);
            Swal.fire({
                title: 'Apakah anda yakin?',
                icon: 'warning',
                showDenyButton: true,
                confirmButtonText: 'Batal',
                denyButtonText: `Hapus`,
            }).then((result) => {
                if (result.isConfirmed) {
                    Swal.fire('', 'Data tidak jadi dihapus', 'success')
                } else if (result.isDenied) {
                    $.ajax({
                        url: '<?php echo e(url("category")); ?>/' + data,
                        type: 'post',
                        data: {_method: 'delete'},
                        success: function (response) {
                            if (response == 1) {
                                Swal.fire({
                                    title: 'Selamat',
                                    text: 'Data Berhasil Dihapus',
                                    icon: 'success'
                                }).then((result) => {
                                    location.reload()
                                })
                            } else {
                                Swal.fire('Ooops', 'Data Gagal Dihapus', 'error')
                            }
                        }
                    })
                }
            })
        })
    })

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ACER\Documents\Plazafood\shopping-seblak\resources\views/category/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', $app_title); ?>

<?php $__env->startSection('content'); ?>

    <style>
        @media (max-width: 576px) {
            .col-xs-2 {
                width: 50%;
            }
        }

        @media (max-width: 300px) {
            .col-xs-2 {
                width: 100%;
            }
        }

    </style>
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800"><?php echo $__env->yieldContent('title'); ?></h1>
    </div>

    <div id="cetak" style="display: none"></div>

    <div class="card">
        <div class="card-body">
            <div class="row">
                <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 mb-2">
                        <div class="card">
                            <div class="card-body">
                                <table>
                                    <tr>
                                        <th>Nama</th>
                                        <td>:</td>
                                        <td><?php echo e($c->name); ?></td>
                                    </tr>
                                    <tr>
                                        <th>No. WA</th>
                                        <td>:</td>
                                        <td><?php echo e($c->phone); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Alamat</th>
                                        <td>:</td>
                                        <td><?php echo e($c->address); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Total Pembayaran</th>
                                        <td>:</td>
                                        <td>Rp. <?php echo e(number_format($c->total, 0, '', '.')); ?></td>
                                    </tr>
                                </table>
                            </div>
                            <div class="card-footer">
                                <form action="<?php echo e(url('order/' . $c->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <button class="btn btn-primary">Selesai</button>
                                    <a href="<?php echo e(url('faktur/' . $c->id)); ?>" target="_blank"
                                        class="btn btn-info btn-faktur">Cetak
                                        Bill</a>
                                    
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-8 mb-3">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">Pesanan <span class="badge bg-success text-white">Pedas Level
                                        <?php echo e($c->level); ?></span></h5>
                                <div class="row">
                                    <?php $__currentLoopData = $c->purchase; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-lg-3 col-md-3 col-sm-4 col-xs-2 mb-3">
                                            <div class="card">
                                                <img src="<?php echo e(url('storage/' . $p->food->image)); ?>" height="100"
                                                    class="card-img-top">
                                                <div class="card-body p-2">
                                                    <p class="card-title product-title mb-0 text-uppercase">
                                                        <strong><?php echo e($p->food->name); ?></strong>
                                                    </p>
                                                    <p class="card-text mb-1">Rp.
                                                        <?php echo e(number_format($p->food->price, 0, '', '.')); ?>

                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ACER\OneDrive\Plazafood\shopping-seblak\resources\views/order/index.blade.php ENDPATH**/ ?>
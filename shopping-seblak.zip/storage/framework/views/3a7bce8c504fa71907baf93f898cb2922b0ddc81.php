<?php $__env->startSection('title', $app_title); ?>

<?php $__env->startSection('content'); ?>

    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800"><?php echo $__env->yieldContent('title'); ?></h1>
    </div>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-md-4">
            <div class="card mb-4" id="tambah-category">
                <div class="card-header">
                    Tambah Kategori
                </div>
                <form action="<?php echo e(url('category')); ?>" method="post">
                    <div class="card-body">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label>Nama Kategori</label>
                            <input type="text" name="name" class="form-control">
                        </div>
                    </div>
                    <div class="card-footer d-flex justify-content-between">
                        <button type="reset" class="btn btn-secondary btn-icon-split btn-sm">
                            <span class="text">Reset</span>
                            <span class="icon text-white-50">
                                <i class="fas fa-redo"></i>
                            </span>
                        </button>
                        <button type="submit" class="btn btn-primary btn-icon-split btn-sm">
                            <span class="text">Tambah</span>
                            <span class="icon text-white-50">
                                <i class="fas fa-save"></i>
                            </span>
                        </button>
                    </div>
                </form>
            </div>
            <div class="card mb-4" id="edit-category">
                <div class="card-header">
                    Edit Kategori
                </div>
                <form action="" method="post" id="form-edit">
                    <div class="card-body">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('patch'); ?>
                        <div class="form-group">
                            <label for="name">Nama Kategori</label>
                            <input type="hidden" name="id" id="id" class="form-control">
                            <input type="text" name="name" id="name" class="form-control">
                        </div>
                    </div>
                    <div class="card-footer d-flex justify-content-between">
                        <button type="reset" class="btn btn-danger btn-icon-split btn-sm btn-batal">
                            <span class="text">Batal</span>
                            <span class="icon text-white-50">
                                <i class="fas fa-times"></i>
                            </span>
                        </button>
                        <button type="submit" class="btn btn-success btn-icon-split btn-sm">
                            <span class="text">Simpan</span>
                            <span class="icon text-white-50">
                                <i class="fas fa-save"></i>
                            </span>
                        </button>
                    </div>
                </form>
            </div>
        </div>
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    Daftar Kategori
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover table-bordered">
                            <thead>
                                <tr>
                                    <th>No.</th>
                                    <th>Kategori</th>
                                    <th>Opsi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th><?php echo e($loop->iteration); ?></th>
                                        <td><?php echo e($c->name); ?></td>
                                        <td>
                                            <button class="btn btn-warning btn-icon-split btn-sm"
                                                data-id="<?php echo e($c->id); ?>" data-name="<?php echo e($c->name); ?>" id="btn-edit">
                                                <span class="text">Edit</span>
                                                <span class="icon text-white-50">
                                                    <i class="fas fa-edit"></i>
                                                </span>
                                            </button>
                                            <button class="btn btn-danger btn-icon-split btn-sm btn-delete"
                                                data-id="<?php echo e($c->id); ?>">
                                                <span class="text">Hapus</span>
                                                <span class="icon text-white-50">
                                                    <i class="fas fa-trash"></i>
                                                </span>
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal-content'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script-content'); ?>
    <script>
        function editCategory(params) {
            $.ajax({
                url: '<?php echo e(url('category')); ?>/' + params,
                type: 'get',
                success: function(response) {
                    $("#form-edit").html(response);
                }
            })
        }

        $(document).ready(function() {
            $('#edit-category').hide();

            $('body').on('click', '#btn-edit', function() {
                $('#edit-category').show();
                $('#tambah-category').hide();

                $('#form-edit').attr('action', '<?php echo e(url('category')); ?>/' + $(this).data('id'));

                $('#id').val($(this).data('id'));
                $('#name').val($(this).data('name'));
            });

            $(".btn-batal").click(function() {
                $('#edit-category').hide();
                $('#tambah-category').show();
            })

            $(".btn-delete").click(function() {
                let data = $(this).data('id');

                Swal.fire({
                    title: 'Apakah anda yakin?',
                    icon: 'warning',
                    showDenyButton: true,
                    confirmButtonText: 'Batal',
                    denyButtonText: `Hapus`,
                }).then((result) => {
                    if (result.isConfirmed) {
                        Swal.fire('', 'Data tidak jadi dihapus', 'success')
                    } else if (result.isDenied) {
                        $.ajax({
                            url: '<?php echo e(url('category')); ?>/' + data,
                            type: 'post',
                            data: {
                                _method: 'delete'
                            },
                            success: function(response) {
                                if (response == 1) {
                                    Swal.fire({
                                        title: 'Selamat',
                                        text: 'Data Berhasil Dihapus',
                                        icon: 'success'
                                    }).then((result) => {
                                        location.reload()
                                    })
                                } else {
                                    Swal.fire('Ooops', 'Data Gagal Dihapus', 'error')
                                }
                            }
                        })
                    }
                })
            })
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ACER\OneDrive\Plazafood\shopping-seblak\resources\views/category/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', $app_title); ?>

<?php $__env->startSection('content'); ?>
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><?php echo $__env->yieldContent('title'); ?></h1>
</div>
<div class="row">
    Lorem ipsum dolor sit amet consectetur adipisicing elit. Modi aperiam expedita praesentium, voluptates, quibusdam perferendis accusantium quae repellat eligendi, possimus quaerat laudantium. Temporibus iusto tempora aliquam sint possimus! Non, exercitationem.
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ACER\Documents\Plazafood\shopping-seblak\resources\views/admin/food.blade.php ENDPATH**/ ?>